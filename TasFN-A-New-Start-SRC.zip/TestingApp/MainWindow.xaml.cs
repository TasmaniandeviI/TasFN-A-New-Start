﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;
using System.Diagnostics;

namespace TestingApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public MessageBoxButton MSGOK { get; private set; }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                string fileName1 = openFileDialog.FileName;
                var fileName = fileName1;
                TextBox.Text = fileName;
            }
        }

        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            if (sender is null)
            {
                throw new ArgumentNullException(nameof(sender));
            }

            var arguments = "FortniteClient-Win64-Shipping.exe -AUTH_LOGIN=TasFNUser@. -AUTH_PASSWORD=TasFNUser -epicportal -noeac -nobe -nohyperion -nobyfron -noac -log -debuglogging -enhancedlogging -logging -debug -logdebug -loggingdebug -enhancedlog -logging";
            var path = TextBox.Text;
            var process3 = Process.Start(path, arguments);
            var process = process3;
            _ = process;

        }

        private void Button3_Click_1(object sender, RoutedEventArgs e)
        {
            {
                if (MessageBox.Show("Do you want to close this window?", "Confirmation", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    Application.Current.Shutdown();
                }
                else
                {
                    
                }
            }
        }

        private void Button4432_Click_1(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("The Application is switching to the 'Settings' Window.", "Warning", MessageBoxButton.OK);
            Window1 window1 = new Window1();
            window1.Show();
            Close();
        }

        private void ChangeLog_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("The Application is switching to the 'ChangeLog' Window.", "Warning", MessageBoxButton.OK);
            ChangeLog window5 = new ChangeLog();
            window5.Show();
            Close();
        }
    }
}
