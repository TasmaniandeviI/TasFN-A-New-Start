﻿using System.Windows;

namespace TasFN_Remake
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2() => InitializeComponent();

        private void Button_Click(object sender,
            RoutedEventArgs e)
        {
            var window3 = new Window3();
            window3.Show();
            Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var mainWindow1 = new MainWindow();
            MainWindow mainWindow = mainWindow1;
            Window window = mainWindow;
            window.Show();
            Close();
        }
    }
}

