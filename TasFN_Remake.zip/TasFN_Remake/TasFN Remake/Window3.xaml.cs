﻿using System.Windows;

namespace TasFN_Remake
{
    /// <summary>
    /// Interaction logic for Window3.xaml
    /// </summary>
    public partial class Window3 : Window
    {
        public Window3() => InitializeComponent();

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Window window = new Window1();
            window.Show();
            Close();
        }
    }
}
