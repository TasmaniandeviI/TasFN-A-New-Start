﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace TasFN_Remake
{
    [DebuggerDisplay("{" + nameof(GetDebuggerDisplay) + "(),nq}")]
    internal class Launcher
    {
        public Launcher()
        {
        }

        public static void PlayGame(string url)
        {
            var file = url;
            using Process process = Process.Start(file);
            _ = process;
        }

        private string GetDebuggerDisplay() => ToString();
    }
}